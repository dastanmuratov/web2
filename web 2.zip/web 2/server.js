const express = require("express");
const app = express();
const port = 3000;

app.use("/styles", express.static(__dirname + '/styles'));

app.use(express.static("src"));
app.use("/", require("./src/vinyl"));
app.use("/contact", require("./src/contact"));
app.use("buy", require("./src/buy"));






app.listen(port, () =>
    console.log(`App listening at http://localhost:${port}`)
);

